"""
M06 Assignment 1 - Alternative Assignment
author: Phil Albonetti
created: 2023-12-01
IDE: Visual Studio Code
Description: This program displays two windows. One window to welcome the user and the other for 
    a data entry field. 

PSEUDOCODE DESCRIPTION OF PROGRAM
This program performs the following steps:
1. imports tkinter for GUI interface
2. Creates color labels for windows
3. Describes the business (dog poo picker-upper) and lets user click Help!
4. User can type address into data entry field
5. User can click close button in 2nd window to close that window.
"""

# import necessary methods from tkinter
import tkinter as tk
from tkinter import ttk
from tkinter import * 

#region Variables
# create GLOBAL Variables for window colors
BG_WINDOW = "#EBC8B0"
LABEL_COLOR = "#70B9C0"
BUTTON_FG = "#6B3C1B"
BUTTON_BG = "#6B3C1B"
#endregion

# class for the second window
class second_window(tk.Toplevel):
    def __init__(self, parent): #opening code to create window
        super().__init__(parent)

        # window configuration
        self.geometry('300x200') # size
        self.title('Customer Info') # name
        self.config(bg=BG_WINDOW) # color

        # label to give instructions to the user
        label0 = Label(self,text="Type your address",font=("Arial",22)) # use Label method to create label
        label0.place(relx = 0.5, rely = 0.15, anchor = CENTER) # position label in the top center
        label0.config(bg=LABEL_COLOR) # label color

        #create the data entry field for the user
        data_field = Entry(self)
        data_field.place(relx = 0.5, rely = 0.3, anchor = CENTER) # position data entry field in the top middle
        data_field.config(bg="#FFFFFF", fg="#000000") # colors for background and font of field

        # creates button to close the second window
        ttk.Button(self,
            text='Close',
            command=self.destroy).pack(expand=True)

# class for the main window
class main_window(tk.Tk):
    def __init__(self):
        super().__init__()

        # window configuration
        self.geometry('300x200') # size
        self.title('Main Window') # name
        self.config(bg=BG_WINDOW) # color

        # informational label for the window
        label0 = Label(self,text="Dog Poo Picker-Upper",font=("Arial",22))
        label0.place(relx = 0.5, rely = 0.1, anchor = CENTER) # label in top center of window
        label0.config(bg = LABEL_COLOR) # color
        
        # sub-label that goes below the top label
        label1 = Label(self,text="Got Poo? Click below for help.", font=("Arial",14))
        label1.place(relx = 0.5, rely = 0.2, anchor = CENTER) # position on scren
        label1.config(bg=LABEL_COLOR) # color


        # button to open the new window
        ttk.Button(self,
                text='Help!',
                command=self.open_window).pack(expand=True) # puts button in center of screen
                
    # calls the 2nd window from the first window
    def open_window(self):
        window = second_window(self)
        window.grab_set()

# code to run the program
if __name__ == "__main__":
    app = main_window()
    app.mainloop()